# NebulaHash – Cloud Mining Dashboard

Next-Gen Cloud Mining Platform – komplett als Single-File Web-App.

Live-Demo: Einfach `index.html` öffnen – kein Build nötig.

![NebulaHash](https://img.shields.io/badge/status-demo-blue) ![License: MIT](https://img.shields.io/badge/License-MIT-green)

## Features

### v2 – aktuell
1. **Referral-System mit Bonus**
   - Eigener Referral-Code pro User (`MINER-XXXX`)
   - Share-Link: `?ref=CODE`
   - 0.00010 BTC Signup-Bonus für den Werber
   - 10% Lifetime-Commission auf Mining-Earnings
   - Referral-Dashboard mit Stats

2. **Live BTC-Preis API**
   - CoinGecko: `https://api.coingecko.com/api/v3/simple/price`
   - Auto-Refresh alle 60s
   - Live-Ticker im Header mit 24h-Change

3. **User Accounts mit Speicherung**
   - Multi-User, Email/Passwort
   - Passwörter SHA-256 client-side gehasht
   - localStorage: `nebulahash_users` + `nebulahash_session`
   - Auto-Login, Profil-Dropdown

4. **Push-Benachrichtigungen**
   - Browser Notifications API
   - Bei: Mining-Payout, Withdrawal, Referral-Bonus, Plan-Upgrade
   - In-App Notification Center mit Glocke
   - Toggle in Settings

### Core
- Live Mining Simulator mit Console
- 3 Pläne: Free (10 TH/s), Starter (100 TH/s), Pro (500 TH/s)
- Earnings Charts (Chart.js)
- Withdraw-Simulator
- Transaction History
- Responsive Dark Neon UI (Tailwind CDN)

> **Hinweis:** Das ist eine Simulations-/Demo-Plattform für Bildungszwecke. Kein echtes Mining.

## Quick Start

```bash
# 1. Klonen
git clone https://github.com/<dein-user>/nebulahash.git
cd nebulahash

# 2. Öffnen
open index.html
# oder mit kleinem Server:
npx serve .
```

Demo-Login:
```
Email: demo@nebulahash.com
Passwort: demo123
```

## Tech Stack

- Vanilla HTML/CSS/JS – Single File, keine Build-Tools
- Tailwind CSS (CDN)
- Chart.js 4.4.0
- Font Awesome 6.5
- localStorage für Persistenz
- CoinGecko API

## Repo Struktur

```
nebulahash/
├── index.html          # Komplette App
├── README.md
├── LICENSE
├── package.json
├── .gitignore
└── .github/workflows/pages.yml  # GitHub Pages Deploy
```

## Deployment

### GitHub Pages
1. Repo auf GitHub pushen
2. Settings → Pages → Source: GitHub Actions
3. Workflow in `.github/workflows/pages.yml` deployed automatisch

### Vercel / Netlify
Einfach das Repo importieren – es ist eine statische Seite, Root = `/`.

## Lizenz

MIT – siehe [LICENSE](LICENSE)

---
Built with NebulaHash v2
