# NebulaHash – Cloud Mining Dashboard v2
Repo mit Referral-System, Live BTC API, User Accounts, Push Notifications.
Quick Start: open index.html oder npx serve .
Demo: demo@nebulahash.com / demo123
